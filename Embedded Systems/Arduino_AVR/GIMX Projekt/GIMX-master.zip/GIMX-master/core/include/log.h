/*
 Copyright (c) 2016 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#ifndef LOG_H_
#define LOG_H_

void log_info();

#endif /* LOG_H_ */
