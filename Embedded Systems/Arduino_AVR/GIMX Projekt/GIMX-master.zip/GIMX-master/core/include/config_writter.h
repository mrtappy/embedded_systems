/*
 Copyright (c) 2011 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#ifndef CONFIG_WRITTER_H_
#define CONFIG_WRITTER_H_

int cfgw_modify_file(char*);

#endif /* CONFIG_WRITTER_H_ */
