/*
 Copyright (c) 2016 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#ifndef CONTROL_H_
#define CONTROL_H_

void control_key(int, int);

#endif /* CONTROL_H_ */
