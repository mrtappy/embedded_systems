/*
 * bt_types.h
 *
 *  Created on: 9 mars 2015
 *      Author: matlo
 */

#ifndef BT_TYPES_H_
#define BT_TYPES_H_



#endif /* BT_TYPES_H_ */
