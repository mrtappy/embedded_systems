/*
 * args.h
 *
 *  Created on: 5 déc. 2012
 *      Author: matlo
 */

#ifndef ARGS_H_
#define ARGS_H_

#include "gimx.h"

int args_read(int argc, char *argv[], s_gimx_params* params);

#endif /* ARGS_H_ */
