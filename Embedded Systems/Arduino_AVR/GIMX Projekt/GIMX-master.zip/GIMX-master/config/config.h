/*
 Copyright (c) 2011 Mathieu Laurendeau <mat.lau@laposte.net>
 License: GPLv3
 */

#include "../info.h"

#define INFO_DESCR "GIMX config editor"
